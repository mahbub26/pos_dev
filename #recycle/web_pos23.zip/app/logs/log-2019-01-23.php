<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-23 14:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\pos2\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 14:51:01 --> Unable to connect to the database
ERROR - 2019-01-23 14:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\pos2\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 14:51:01 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\pos2\system\libraries\Session\Session_driver.php 205
ERROR - 2019-01-23 14:51:01 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\pos2\system\libraries\Session\Session.php 143
ERROR - 2019-01-23 14:51:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\pos2\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 14:51:01 --> Unable to connect to the database
ERROR - 2019-01-23 14:51:01 --> Query error: Access denied for user 'dbuser'@'localhost' (using password: YES) - Invalid query: SELECT *
FROM `sma_settings`
ERROR - 2019-01-23 14:51:01 --> Severity: error --> Exception: Call to a member function num_rows() on boolean C:\xampp\htdocs\pos2\app\models\Site.php 42
ERROR - 2019-01-23 15:31:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\poss\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 15:31:45 --> Unable to connect to the database
ERROR - 2019-01-23 15:31:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\poss\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 15:31:45 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\poss\system\libraries\Session\Session_driver.php 205
ERROR - 2019-01-23 15:31:45 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\poss\system\libraries\Session\Session.php 143
ERROR - 2019-01-23 15:31:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\poss\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 15:31:45 --> Unable to connect to the database
ERROR - 2019-01-23 15:31:45 --> Query error: Access denied for user 'dbuser'@'localhost' (using password: YES) - Invalid query: SELECT *
FROM `sma_settings`
ERROR - 2019-01-23 15:31:45 --> Severity: error --> Exception: Call to a member function num_rows() on boolean C:\xampp\htdocs\poss\app\models\Site.php 42
ERROR - 2019-01-23 18:11:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\poss\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 18:11:33 --> Unable to connect to the database
ERROR - 2019-01-23 18:11:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\poss\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 18:11:34 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time C:\xampp\htdocs\poss\system\libraries\Session\Session_driver.php 205
ERROR - 2019-01-23 18:11:34 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: C:\xampp\tmp) C:\xampp\htdocs\poss\system\libraries\Session\Session.php 143
ERROR - 2019-01-23 18:11:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'dbuser'@'localhost' (using password: YES) C:\xampp\htdocs\poss\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2019-01-23 18:11:34 --> Unable to connect to the database
ERROR - 2019-01-23 18:11:34 --> Query error: Access denied for user 'dbuser'@'localhost' (using password: YES) - Invalid query: SELECT *
FROM `sma_settings`
ERROR - 2019-01-23 18:11:34 --> Severity: error --> Exception: Call to a member function num_rows() on boolean C:\xampp\htdocs\poss\app\models\Site.php 42
