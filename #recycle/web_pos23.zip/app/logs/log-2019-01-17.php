<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-17 19:27:35 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:35 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:35 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:35 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:27:39 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:27:39 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:29:02 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:29:02 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:29:02 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:29:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/Saleem/Desktop/Projects/ci/sma/system/core/Exceptions.php:271) /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Renderer/Image.php 318
ERROR - 2019-01-17 19:31:05 --> Severity: error --> Exception: Call to undefined function dd() /Users/Saleem/Desktop/Projects/ci/sma/app/controllers/admin/Misc.php 17
ERROR - 2019-01-17 19:31:21 --> Severity: error --> Exception: Call to undefined function dd() /Users/Saleem/Desktop/Projects/ci/sma/app/controllers/admin/Misc.php 17
ERROR - 2019-01-17 19:32:08 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:08 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:32:08 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:32:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/Saleem/Desktop/Projects/ci/sma/system/core/Exceptions.php:271) /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Renderer/Image.php 318
ERROR - 2019-01-17 19:32:22 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 262
ERROR - 2019-01-17 19:32:22 --> Severity: Notice --> Undefined index:  /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:32:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Object/Code128.php 227
ERROR - 2019-01-17 19:32:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Users/Saleem/Desktop/Projects/ci/sma/system/core/Exceptions.php:271) /Users/Saleem/Desktop/Projects/ci/sma/vendor/zendframework/zend-barcode/src/Renderer/Image.php 318
ERROR - 2019-01-17 19:35:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) /Users/Saleem/Desktop/Projects/ci/sma/app/libraries/Sma.php 523
ERROR - 2019-01-17 19:35:10 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) /Users/Saleem/Desktop/Projects/ci/sma/app/libraries/Sma.php 523
ERROR - 2019-01-17 19:35:13 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) /Users/Saleem/Desktop/Projects/ci/sma/app/libraries/Sma.php 523
ERROR - 2019-01-17 19:35:14 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) /Users/Saleem/Desktop/Projects/ci/sma/app/libraries/Sma.php 523
ERROR - 2019-01-17 19:40:44 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' /Users/Saleem/Desktop/Projects/ci/sma/app/libraries/Sma.php 508
ERROR - 2019-01-17 19:40:47 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' /Users/Saleem/Desktop/Projects/ci/sma/app/libraries/Sma.php 508
