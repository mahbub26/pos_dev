<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-26 11:34:09 --> Could not find the language line "logout_successful"
ERROR - 2018-11-26 11:34:09 --> Could not find the language line "logout_successful"
