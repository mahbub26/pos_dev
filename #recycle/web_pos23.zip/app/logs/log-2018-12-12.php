<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-12 19:52:24 --> Severity: Notice --> Undefined property: Auth::$Owner /Users/Saleem/Desktop/Projects/ci/sma/app/controllers/admin/Auth.php 521
